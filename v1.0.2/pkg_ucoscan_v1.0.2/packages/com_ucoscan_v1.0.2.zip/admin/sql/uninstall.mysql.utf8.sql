DROP TABLE IF EXISTS `#__ucoscan_ucoscansite`;
DROP TABLE IF EXISTS `#__ucoscan_domain`;
DROP TABLE IF EXISTS `#__ucoscan_suffix`;
DROP TABLE IF EXISTS `#__ucoscan_cms`;